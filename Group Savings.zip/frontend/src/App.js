// frontend/src/App.js
import React, { useState } from 'react';
import PersonSelector from './components/PersonSelector';
import BalanceView from './components/BalanceView';
import SaveUnitsForm from './components/SaveUnitsForm';
import BorrowForm from './components/BorrowForm';
import RepayForm from './components/RepayForm';
import RetroactiveForm from './components/RetroactiveForm';
import TransactionLog from './components/TransactionLog';
import CreateMemberForm from './components/CreateMemberForm';

function App() {
  const [personId, setPersonId] = useState(null);
  // used to force refresh child components
  const [refreshFlag, setRefreshFlag] = useState(0);
  const refreshAll = () => setRefreshFlag(f => f + 1);

  // toggle create-member form
  const [showCreateMember, setShowCreateMember] = useState(false);

  return (
    <div style={{ padding: 20, fontFamily: 'Arial, sans-serif' }}>
      <h1>Group Savings</h1>

      <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
        <PersonSelector selectedId={personId} onChange={setPersonId} />
        <button onClick={() => setShowCreateMember(s => !s)} style={{ height: 32 }}>
          {showCreateMember ? 'Hide' : 'Create member (admin)'}
        </button>
        <button onClick={refreshAll} style={{ height: 32 }}>Refresh</button>
      </div>

      {showCreateMember && <div style={{ marginTop: 12 }}><CreateMemberForm onCreated={refreshAll} /></div>}

      <BalanceView personId={personId || 0} refreshFlag={refreshFlag} />

      <div style={{ display: 'flex', gap: 20, marginTop: 12 }}>
        <div style={{ flex: 1 }}>
          <SaveUnitsForm personId={personId} onSaved={refreshAll} />
          <BorrowForm personId={personId} onDone={refreshAll} />
          <RepayForm personId={personId} onPaid={refreshAll} />
        </div>

        <div style={{ flex: 1 }}>
          <RetroactiveForm personId={personId} onSaved={refreshAll} />
          <TransactionLog personId={personId} />
        </div>
      </div>
    </div>
  );
}

export default App;
