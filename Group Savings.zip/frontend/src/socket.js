// frontend/src/socket.js
import { io } from 'socket.io-client';
const SERVER = process.env.REACT_APP_BACKEND_URL || 'http://localhost:4000';
const socket = io(SERVER, { autoConnect: true });
export default socket;
