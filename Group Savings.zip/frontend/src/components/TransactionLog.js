// frontend/src/components/TransactionLog.js
import React, { useEffect, useState } from 'react';
import socket from '../socket';

export default function TransactionLog({ personId }) {
  const [tx, setTx] = useState([]);

  async function load() {
    if (!personId) { setTx([]); return; }
    try {
      const res = await fetch(`http://localhost:4000/api/people/${personId}/transactions`);
      const j = await res.json();
      setTx(j.transactions || []);
    } catch (err) {
      console.error(err);
    }
  }

  useEffect(() => {
    load();
    const handler = (payload) => {
      if (!payload || payload.personId === 0 || payload.personId === personId) load();
    };
    socket.on('update', handler);
    return () => socket.off('update', handler);
  }, [personId]);

  if (!personId) return <div className="card"><em>Select a person to view transactions</em></div>;

  return (
    <div className="card">
      <h3>Transactions</h3>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th style={{ borderBottom: '1px solid #ccc', textAlign: 'left' }}>Date</th>
            <th style={{ borderBottom: '1px solid #ccc', textAlign: 'left' }}>Type</th>
            <th style={{ borderBottom: '1px solid #ccc', textAlign: 'right' }}>Amount</th>
            <th style={{ borderBottom: '1px solid #ccc', textAlign: 'left' }}>Details</th>
          </tr>
        </thead>
        <tbody>
          {tx.length === 0 && <tr><td colSpan="4">No transactions yet</td></tr>}
          {tx.map(t => {
            let details = '';
            try {
              const d = t.details ? JSON.parse(t.details) : {};
              // select a few fields to summarize
              if (d.poolType) details += d.poolType + ' ';
              if (d.principal) details += `P:${d.principal} `;
              if (d.borrowingId) details += `#${d.borrowingId} `;
              if (d.appliedUnits) details += `${d.appliedUnits} units `;
              if (d.appliedValidity) details += `validity:${d.appliedValidity} `;
              if (d.fullPay) details += 'full-pay';
            } catch (e) { details = t.details || ''; }
            return (
              <tr key={t.id}>
                <td style={{ padding: '6px 4px', borderBottom: '1px solid #eee' }}>{new Date(t.created_at).toLocaleString()}</td>
                <td style={{ padding: '6px 4px', borderBottom: '1px solid #eee' }}>{t.transaction_type}</td>
                <td style={{ padding: '6px 4px', borderBottom: '1px solid #eee', textAlign: 'right' }}>{Number(t.amount).toFixed(2)}</td>
                <td style={{ padding: '6px 4px', borderBottom: '1px solid #eee' }}>{details}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
