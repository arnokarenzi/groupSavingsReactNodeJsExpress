import React, { useEffect, useState } from 'react';

export default function PersonSelector({ selectedId, onChange }) {
  const [people, setPeople] = useState([]);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch('http://localhost:4000/api/people');
        const j = await res.json();
        setPeople(j.people || []);
      } catch (err) {
        console.error(err);
      }
    }
    load();
  }, []);

  return (
    <div style={{ marginBottom: 12 }}>
      <label>
        Person:
        <select value={selectedId || ''} onChange={e => onChange(parseInt(e.target.value) || null)} style={{ marginLeft: 8 }}>
          <option value="">--select person--</option>
          {people.map(p => <option key={p.id} value={p.id}>{p.name} (#{p.id})</option>)}
        </select>
      </label>
    </div>
  );
}
