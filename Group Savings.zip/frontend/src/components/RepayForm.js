// frontend/src/components/RepayForm.js
import React, { useEffect, useState } from 'react';
import socket from '../socket';

export default function RepayForm({ personId, onPaid }) {
  const [selectedPool, setSelectedPool] = useState('MAIN'); // 'MAIN' or 'VALIDITY'
  const [openBorrowing, setOpenBorrowing] = useState(null);
  const [amount, setAmount] = useState('');
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(false);

  async function load() {
    setMsg(null);
    setOpenBorrowing(null);
    if (!personId) return;
    try {
      const res = await fetch(`http://localhost:4000/api/people/${personId}/balance`);
      const j = await res.json();
      const open = j.openBorrowings || [];
      const found = open.find(b => b.pool_type === selectedPool);
      setOpenBorrowing(found || null);
    } catch (err) {
      setMsg('Cannot fetch borrowings (backend?).');
    }
  }

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [personId, selectedPool]);

  useEffect(() => {
    const handler = (payload) => {
      if (!payload) return;
      if (payload.personId === 0 || payload.personId === personId) load();
    };
    socket.on('update', handler);
    return () => socket.off('update', handler);
  }, [personId, selectedPool]);

  async function payFull() {
    if (!personId) { setMsg('Select a person first'); return; }
    if (!openBorrowing) { setMsg('No open borrowing for selected pool'); return; }

    const confirmMsg = `Pay FULL outstanding ${openBorrowing.outstanding_amount} for borrowing #${openBorrowing.id}?`;
    if (!window.confirm(confirmMsg)) return;

    setLoading(true);
    try {
      const res = await fetch(`http://localhost:4000/api/people/${personId}/pay_full`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ poolType: selectedPool })
      });
      const j = await res.json();
      if (!res.ok) setMsg(JSON.stringify(j));
      else {
        setMsg(`Full payment applied: ${j.paidAmount}`);
        setAmount('');
        if (onPaid) onPaid();
        load();
      }
    } catch (err) {
      setMsg('Network error when paying full.');
    } finally {
      setLoading(false);
    }
  }

  async function payPartial(e) {
    e.preventDefault();
    if (!personId) { setMsg('Select a person first'); return; }
    if (!openBorrowing) { setMsg('No open borrowing for selected pool'); return; }
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) { setMsg('Enter a positive amount'); return; }

    const confirmMsg = `Pay partial ${amt} towards borrowing #${openBorrowing.id} (outstanding ${openBorrowing.outstanding_amount})?`;
    if (!window.confirm(confirmMsg)) return;

    setLoading(true);
    try {
      const res = await fetch(`http://localhost:4000/api/people/${personId}/repay`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ borrowingId: openBorrowing.id, amount: amt })
      });
      const j = await res.json();
      if (!res.ok) setMsg(JSON.stringify(j));
      else {
        setMsg(`Partial payment accepted. New outstanding: ${j.newOutstanding}`);
        setAmount('');
        if (onPaid) onPaid();
        load();
      }
    } catch (err) {
      setMsg('Network error when repaying.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card">
      <h3>Repay</h3>

      <div>
        <label style={{ marginRight: 12 }}>
          <input type="radio" name="repayPool" value="MAIN" checked={selectedPool === 'MAIN'} onChange={() => setSelectedPool('MAIN')} />
          Main
        </label>
        <label>
          <input type="radio" name="repayPool" value="VALIDITY" checked={selectedPool === 'VALIDITY'} onChange={() => setSelectedPool('VALIDITY')} />
          Validity
        </label>
      </div>

      <div style={{ marginTop: 8 }}>
        {!personId && <div style={{ color: '#777' }}>Select a person to see open borrowings.</div>}
        {personId && openBorrowing === null && <div>No open borrowing for {selectedPool} pool.</div>}
        {personId && openBorrowing && (
          <div>
            <div>Borrowing #{openBorrowing.id} — Outstanding: {openBorrowing.outstanding_amount} — Due: {openBorrowing.due_date}</div>

            <form onSubmit={payPartial} style={{ marginTop: 8 }}>
              <label>
                Partial amount:
                <input value={amount} onChange={e => setAmount(e.target.value)} style={{ marginLeft: 8 }} />
              </label>
              <button type="submit" style={{ marginLeft: 8 }} disabled={loading}>Pay partial</button>
            </form>

            <div style={{ marginTop: 8 }}>
              <button onClick={payFull} disabled={loading}>Pay full ({openBorrowing.outstanding_amount})</button>
            </div>
          </div>
        )}
      </div>

      {msg && <pre style={{ marginTop: 8 }}>{msg}</pre>}
    </div>
  );
}
