// frontend/src/components/BorrowForm.js
import React, { useEffect, useState } from 'react';
import socket from '../socket';

export default function BorrowForm({ personId, onDone }) {
  const [poolType, setPoolType] = useState('MAIN');
  const [amount, setAmount] = useState('');
  const [msg, setMsg] = useState(null);
  const [meta, setMeta] = useState({ savedCount: 0 });
  const [openBorrowings, setOpenBorrowings] = useState([]);
  const [groupPools, setGroupPools] = useState([]);

  const [adminOverride, setAdminOverride] = useState(false);
  const [adminPw, setAdminPw] = useState('');

  async function load() {
    setMsg(null);
    if (!personId) return;
    try {
      // load meta
      const r1 = await fetch(`http://localhost:4000/api/people/${personId}/meta`);
      const m = await r1.json();
      setMeta(m);

      // load balance + open borrowings, group pools
      const r2 = await fetch(`http://localhost:4000/api/people/${personId}/balance`);
      const j = await r2.json();
      setOpenBorrowings(j.openBorrowings || []);
      setGroupPools(j.groupPools || []);
    } catch (err) {
      console.error(err);
      setMsg('Cannot reach backend');
    }
  }

  useEffect(() => {
    load();
    const handler = (payload) => {
      // refresh when relevant person or global updates
      if (!payload || payload.personId === 0 || payload.personId === personId) load();
    };
    socket.on('update', handler);
    return () => socket.off('update', handler);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [personId]);

  function canBorrowThisPool() {
    // savedCount >= 3 required
    if (!personId) return false;
    if (adminOverride) return true;
    if ((meta.savedCount || 0) < 3) return false;
    // check if open borrowing exists in same pool
    const existing = openBorrowings.find(b => b.pool_type === poolType && b.status === 'OPEN');
    if (existing) return false;
    return true;
  }

  function getPoolBalance(pool) {
    const p = (groupPools || []).find(g => g.pool_type === pool);
    return p ? p.balance : 0;
  }

  async function submit(e) {
    e.preventDefault();
    setMsg(null);
    if (!personId) return setMsg('Select a person first');
    if (!amount || parseFloat(amount) <= 0) return setMsg('Enter amount');

    if (!window.confirm(`Create borrow from ${poolType} for ${amount}?${adminOverride ? ' Using Admin Exception' : ''}`)) return;

    const payload = { poolType, amount: parseFloat(amount) };
    if (adminOverride) {
      if (!adminPw) return setMsg('Admin password required for override');
      payload.adminOverride = true;
      payload.adminPassword = adminPw;
    }

    try {
      const res = await fetch(`http://localhost:4000/api/people/${personId}/borrow`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const j = await res.json();
      if (!res.ok) setMsg(JSON.stringify(j));
      else {
        setMsg(`Borrow created: outstanding ${j.outstanding} due ${j.dueDate}`);
        setAmount('');
        if (onDone) onDone();
      }
    } catch (err) {
      setMsg('Network error');
    }
  }

  const savedOk = (meta.savedCount || 0) >= 3;
  const existingThisPool = openBorrowings.find(b => b.pool_type === poolType);

  return (
    <div className="card">
      <h3>Borrow</h3>
      <div>
        <label>
          Amount: <input value={amount} onChange={e => setAmount(e.target.value)} />
        </label>
      </div>

      <div style={{ marginTop: 8 }}>
        <label><input type="radio" name="pool" value="MAIN" checked={poolType==='MAIN'} onChange={() => setPoolType('MAIN')} /> Main (pool balance: {getPoolBalance('MAIN')})</label>
        <label style={{ marginLeft: 12 }}><input type="radio" name="pool" value="VALIDITY" checked={poolType==='VALIDITY'} onChange={() => setPoolType('VALIDITY')} /> Validity (pool balance: {getPoolBalance('VALIDITY')})</label>
      </div>

      <div style={{ marginTop: 8 }}>
        <div>Saved count: {meta.savedCount}</div>
        {existingThisPool ? <div style={{ color: 'orange' }}>Warning: you have an open {poolType} borrowing (#{existingThisPool.id})</div> : null}
        {!savedOk && !adminOverride && <div style={{ color: 'red' }}>You must have saved at least 3 times to borrow.</div>}
      </div>

      <div style={{ marginTop: 8 }}>
        <label><input type="checkbox" checked={adminOverride} onChange={e => setAdminOverride(e.target.checked)} /> Use Admin Exception (overrules checks)</label>
        {adminOverride && <div style={{ marginTop: 6 }}><label>Admin password: <input type="password" value={adminPw} onChange={e => setAdminPw(e.target.value)} /></label></div>}
      </div>

      <div style={{ marginTop: 10 }}>
        <button disabled={!personId} onClick={submit}>Borrow</button>
      </div>
      {msg && <pre style={{ marginTop: 8 }}>{msg}</pre>}
    </div>
  );
}
