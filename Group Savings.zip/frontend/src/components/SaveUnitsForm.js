// frontend/src/components/SaveUnitsForm.js
import React, { useEffect, useState } from 'react';
import socket from '../socket';

export default function SaveUnitsForm({ personId, onSaved }) {
  const [units, setUnits] = useState(0);
  const [payValidity, setPayValidity] = useState(false);
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(false);

  // refresh after realtime updates that may affect this form's state
  useEffect(() => {
    const handler = (payload) => {
      if (!payload) return;
      if (payload.personId === 0 || payload.personId === personId) {
        // For simplicity we just clear messages so user sees updates in other components
        setMsg(null);
      }
    };
    socket.on('update', handler);
    return () => socket.off('update', handler);
  }, [personId]);

  async function submit(e) {
    e.preventDefault();
    setMsg(null);
    if (!personId) { setMsg('Select a person first'); return; }
    if (units < 0 || units > 4) { setMsg('Units must be between 0 and 4'); return; }

    const confirmMsg = `Are you sure you want to save ${units} unit(s)${payValidity ? ' and pay validity ($100)' : ''} for person #${personId}?`;
    if (!window.confirm(confirmMsg)) return;

    setLoading(true);
    try {
      const res = await fetch(`http://localhost:4000/api/people/${personId}/save`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ units: Number(units), payValidity })
      });
      const j = await res.json();
      if (!res.ok) {
        setMsg(JSON.stringify(j));
      } else {
        // server returns applied summary and newBalances
        setMsg('Saved. Applied: ' + JSON.stringify(j.applied || {}) + '\nNew balances: ' + JSON.stringify(j.newBalances));
        // notify parent to reload immediately
        if (onSaved) onSaved();
      }
    } catch (err) {
      setMsg('Network error');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card">
      <h3>Save units for today</h3>
      <form onSubmit={submit}>
        <label>
          Units (0-4):
          <input
            type="number"
            min="0"
            max="4"
            value={units}
            onChange={e => setUnits(Number(e.target.value))}
            style={{ marginLeft: 8 }}
          />
        </label>
        <label style={{ display: 'block', marginTop: 8 }}>
          <input type="checkbox" checked={payValidity} onChange={e => setPayValidity(e.target.checked)} />
          Pay validity ($100)
        </label>

        <div style={{ marginTop: 8 }}>
          <button type="submit" disabled={loading}>Save</button>
        </div>
      </form>
      {msg && <pre style={{ marginTop: 8 }}>{msg}</pre>}
    </div>
  );
}
