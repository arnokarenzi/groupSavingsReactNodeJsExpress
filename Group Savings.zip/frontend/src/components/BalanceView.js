// frontend/src/components/BalanceView.js
import React, { useEffect, useState } from 'react';
import socket from '../socket';

export default function BalanceView({ personId, refreshFlag }) {
  const [loading, setLoading] = useState(false);
  const [personBal, setPersonBal] = useState({ main_savings_balance: 0, validity_savings_balance: 0 });
  const [openBorrowings, setOpenBorrowings] = useState([]);
  const [groupPools, setGroupPools] = useState([]);

  async function load() {
    if (!personId || personId === 0) {
      // still load group pools if no person selected
      try {
        setLoading(true);
        const res = await fetch(`http://localhost:4000/api/people/${personId || 0}/balance`);
        const j = await res.json();
        setPersonBal(j.person || { main_savings_balance: 0, validity_savings_balance: 0 });
        setOpenBorrowings(j.openBorrowings || []);
        setGroupPools(j.groupPools || []);
      } catch (err) {
        console.error('BalanceView load error', err);
      } finally {
        setLoading(false);
      }
      return;
    }

    try {
      setLoading(true);
      const res = await fetch(`http://localhost:4000/api/people/${personId}/balance`);
      const j = await res.json();
      setPersonBal(j.person || { main_savings_balance: 0, validity_savings_balance: 0 });
      setOpenBorrowings(j.openBorrowings || []);
      setGroupPools(j.groupPools || []);
    } catch (err) {
      console.error('BalanceView load error', err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line
  }, [personId, refreshFlag]);

  useEffect(() => {
    // refresh when socket informs of relevant update
    const handler = (payload) => {
      try {
        if (!payload) { load(); return; }
        if (payload.personId === 0 || payload.personId === personId) load();
      } catch (e) { /* swallow */ }
    };
    socket.on('update', handler);
    return () => socket.off('update', handler);
  }, [personId]);

  const findPool = (type) => {
    const p = (groupPools || []).find(g => g.pool_type === type);
    return p ? Number(p.balance).toFixed(2) : '0.00';
  };

  return (
    <div className="card" style={{ marginBottom: 12 }}>
      <h3>Balances</h3>
      {loading && <div style={{ color: '#666' }}>Loading...</div>}
      <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
        <div>
          <strong>Personal</strong>
          <div>Main savings: {Number(personBal.main_savings_balance || 0).toFixed(2)}</div>
          <div>Validity savings: {Number(personBal.validity_savings_balance || 0).toFixed(2)}</div>
        </div>

        <div>
          <strong>Group pools</strong>
          <div>Main pool: {findPool('MAIN')}</div>
          <div>Validity pool: {findPool('VALIDITY')}</div>
        </div>

        <div style={{ flex: 1 }}>
          <strong>Open borrowings</strong>
          {(!openBorrowings || openBorrowings.length === 0) && <div style={{ color: '#777' }}>No open borrowing</div>}
          {openBorrowings && openBorrowings.map(b => (
            <div key={b.id} style={{ marginBottom: 6 }}>
              #{b.id} — {b.pool_type} — outstanding: {Number(b.outstanding_amount).toFixed(2)} — due: {b.due_date}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
