// frontend/src/components/RetroactiveForm.js
import React, { useEffect, useState } from 'react';
import socket from '../socket';

export default function RetroactiveForm({ personId, onSaved }) {
  // default to yesterday
  const yesterday = new Date(Date.now() - 24 * 3600 * 1000).toISOString().slice(0,10);
  const [date, setDate] = useState(yesterday);
  const [units, setUnits] = useState(0);
  const payValidity = true; // always checked & disabled
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const handler = (payload) => {
      if (!payload) return;
      if (payload.personId === 0 || payload.personId === personId) {
        setMsg(null);
      }
    };
    socket.on('update', handler);
    return () => socket.off('update', handler);
  }, [personId]);

  async function submit(e) {
    e.preventDefault();
    setMsg(null);
    if (!personId) { setMsg('Select a person first'); return; }
    if (!date) { setMsg('Select a date'); return; }
    if (units < 0 || units > 4) { setMsg('Units must be between 0 and 4'); return; }

    const confirmMsg = `Apply retroactive fill for ${date} with ${units} unit(s) and pay validity ($100 if missing)?`;
    if (!window.confirm(confirmMsg)) return;

    setLoading(true);
    try {
      const res = await fetch(`http://localhost:4000/api/people/${personId}/retroactive`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ date, addUnits: parseInt(units, 10), payValidityIfMissing: payValidity })
      });
      const j = await res.json();
      if (!res.ok) setMsg(JSON.stringify(j));
      else {
        setMsg('Retroactive applied: ' + JSON.stringify(j.applied || j));
        if (onSaved) onSaved();
      }
    } catch (err) {
      setMsg('Network error for retroactive call.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card">
      <h3>Retroactive Fill (pick a past date)</h3>
      <form onSubmit={submit}>
        <label>
          Date:
          <input type="date" value={date} onChange={e => setDate(e.target.value)} max={new Date().toISOString().slice(0,10)} style={{ marginLeft: 8 }} />
        </label>
        <label style={{ display: 'block', marginTop: 8 }}>
          Add units (0-4):
          <input type="number" min="0" max="4" value={units} onChange={e => setUnits(Number(e.target.value))} style={{ marginLeft: 8 }} />
        </label>
        <label style={{ display: 'block', marginTop: 8 }}>
          <input type="checkbox" checked={true} disabled /> Pay validity if missing ($100) — always checked
        </label>

        <div style={{ marginTop: 8 }}>
          <button type="submit" disabled={loading}>Apply Retroactive Fill</button>
        </div>
      </form>
      {msg && <pre style={{ marginTop: 8 }}>{msg}</pre>}
      <div style={{ marginTop: 8, fontSize: 12, color: '#555' }}>
        Note: fines ($500) are applied only when adding units (>0) for a missing day.
      </div>
    </div>
  );
}
