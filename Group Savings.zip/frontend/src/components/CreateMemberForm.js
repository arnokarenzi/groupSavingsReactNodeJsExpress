// frontend/src/components/CreateMemberForm.js
import React, { useState } from 'react';

export default function CreateMemberForm({ onCreated }) {
  const [name, setName] = useState('');
  const [adminPw, setAdminPw] = useState('');
  const [msg, setMsg] = useState(null);

  async function submit(e) {
    e.preventDefault();
    setMsg(null);
    if (!name) return setMsg('Name required');
    if (!adminPw) return setMsg('Admin password required');

    if (!window.confirm(`Create new member "${name}"?`)) return;

    try {
      const res = await fetch('http://localhost:4000/api/people', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, adminPassword: adminPw })
      });
      const j = await res.json();
      if (!res.ok) setMsg(JSON.stringify(j));
      else {
        setMsg(`Member created: ${j.personId}`);
        setName('');
        setAdminPw('');
        if (onCreated) onCreated();
      }
    } catch (err) {
      setMsg('Network error');
    }
  }

  return (
    <div className="card">
      <h3>Create Member (admin)</h3>
      <form onSubmit={submit}>
        <label>Name: <input value={name} onChange={e => setName(e.target.value)} /></label>
        <label>Admin password: <input type="password" value={adminPw} onChange={e => setAdminPw(e.target.value)} /></label>
        <div style={{ marginTop: 8 }}>
          <button type="submit">Create</button>
        </div>
      </form>
      {msg && <pre>{msg}</pre>}
    </div>
  );
}
